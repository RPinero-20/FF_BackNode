-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 11-12-2023 a las 15:57:38
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `f_ferlestore`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ff_categories`
--

CREATE TABLE `ff_categories` (
  `id` int(4) NOT NULL COMMENT 'IDdeCategoría',
  `name` varchar(64) NOT NULL,
  `sectionID` int(3) NOT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `ff_categories`
--

INSERT INTO `ff_categories` (`id`, `name`, `sectionID`, `description`, `createdAt`, `updatedAt`) VALUES
(1, 'Sierras de mano', 1, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(2, 'Cepillos', 1, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(3, 'Formones', 1, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(4, 'Gubias', 1, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(5, 'Escoplos', 1, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(6, 'Sierras eléctricas', 2, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(7, 'Cepilladoras eléctricas', 2, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(8, 'Fresadoras', 2, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(9, 'Lijadoras', 2, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(10, 'Maderas', 3, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(11, 'Tableros', 3, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(12, 'Laminados', 3, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(13, 'Barnices', 3, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(14, 'Adhesivos', 3, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(15, 'Cables eléctricos', 4, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(16, 'Enchufes', 4, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(17, 'Interruptores', 4, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(18, 'Iluminación', 4, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(19, 'Bisagras', 5, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(20, 'Cerraduras', 5, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(21, 'Tiradores', 5, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(22, 'Guías para cajones', 5, '', '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(23, 'Sistemas de correderas', 5, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(24, 'Perfiles decorativos', 6, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(25, 'Molduras', 6, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(26, 'Patas para muebles', 6, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(27, 'Elementos de diseño', 6, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(28, 'Gafas de seguridad', 7, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(29, 'Guantes', 7, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(30, 'Protectores auditivos', 7, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26'),
(31, 'Mascarillas respiratorias', 7, NULL, '2023-11-24 15:59:26', '2023-11-24 15:59:26');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ff_clients`
--

CREATE TABLE `ff_clients` (
  `id` int(11) NOT NULL,
  `rif` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `address` varchar(1024) NOT NULL,
  `email` varchar(64) DEFAULT NULL,
  `phone_number` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ff_client_orders`
--

CREATE TABLE `ff_client_orders` (
  `id` int(11) NOT NULL,
  `client_id` int(64) NOT NULL,
  `date` int(11) NOT NULL,
  `total_products` int(11) DEFAULT NULL,
  `total_price` decimal(10,3) NOT NULL,
  `status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ff_orders`
--

CREATE TABLE `ff_orders` (
  `id` int(200) NOT NULL COMMENT 'order_idDevControl',
  `client_id` varchar(64) NOT NULL,
  `client_name` varchar(64) NOT NULL,
  `client_phone` varchar(15) NOT NULL,
  `pay_number` varchar(64) NOT NULL,
  `date` date NOT NULL,
  `total_price` decimal(15,3) NOT NULL,
  `status` varchar(20) NOT NULL,
  `bank` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ff_order_details`
--

CREATE TABLE `ff_order_details` (
  `id` int(11) NOT NULL COMMENT 'IDControlDev',
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `product_unit_price` decimal(15,3) NOT NULL,
  `address_arrival` varchar(2048) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ff_products`
--

CREATE TABLE `ff_products` (
  `id` int(15) NOT NULL COMMENT 'IDControlDev',
  `code` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `type` varchar(64) NOT NULL,
  `byWeight` tinyint(1) DEFAULT 0,
  `weightPerUnit` decimal(5,3) DEFAULT NULL,
  `weightPerBox` decimal(5,3) DEFAULT NULL,
  `byUnit` tinyint(1) NOT NULL DEFAULT 0,
  `unitQty` int(11) NOT NULL DEFAULT 0,
  `unitPerBox` int(11) NOT NULL DEFAULT 0,
  `price` decimal(15,3) NOT NULL,
  `isOffer` tinyint(1) NOT NULL DEFAULT 0,
  `isFree` tinyint(1) NOT NULL DEFAULT 0,
  `isOutStock` tinyint(1) NOT NULL DEFAULT 0,
  `description` varchar(200) DEFAULT NULL,
  `imageUrl` varchar(140) NOT NULL,
  `categoryID` int(4) NOT NULL,
  `sectionID` int(3) NOT NULL,
  `discount` int(2) NOT NULL DEFAULT 0,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci COMMENT='Productos';

--
-- Volcado de datos para la tabla `ff_products`
--

INSERT INTO `ff_products` (`id`, `code`, `name`, `type`, `byWeight`, `weightPerUnit`, `weightPerBox`, `byUnit`, `unitQty`, `unitPerBox`, `price`, `isOffer`, `isFree`, `isOutStock`, `description`, `imageUrl`, `categoryID`, `sectionID`, `discount`, `createdAt`, `updatedAt`) VALUES
(1, 'SAW001', 'Sierra de mano', 'Herramienta manual', 0, 0.800, NULL, 1, 1, 0, 15.990, 0, 0, 0, 'Sierra de mano con hoja de acero templado y mango antideslizante.', 'http://127.0.0.1:8000/assets/images/productsThumbnails/numero01.jpg', 1, 1, 0, '2023-11-22 01:11:44', '2023-11-22 01:11:44'),
(2, 'CHI003', 'Formón de carpintero\r\n', 'Herramienta manual', 0, 0.300, NULL, 1, 1, 0, 8.990, 0, 0, 0, 'Formón de carpintero con hoja de acero endurecido y mango ergonómico.', 'http://127.0.0.1:8000/assets/images/productsThumbnails/numero02.jpg', 1, 1, 0, '2023-11-22 01:19:46', '2023-11-22 01:19:46'),
(3, 'SAW004', 'Serrucho', 'Herramienta manual', 0, 0.600, NULL, 1, 1, 0, 12.990, 1, 0, 0, 'Serrucho de carpintero con dientes afilados y mango antideslizante.', 'http://127.0.0.1:8000/assets/images/productsThumbnails/numero03.jpg', 1, 1, 0, '2023-11-22 01:19:46', '2023-11-22 01:19:46'),
(4, 'SQU005', 'Escuadra de carpintero\r\n', 'Herramienta manual\r\n', 0, 0.200, NULL, 1, 0, 0, 6.990, 1, 0, 0, 'Escuadra de carpintero de acero resistente con medidas grabadas.\r\n', 'http://127.0.0.1:8000/assets/images/productsThumbnails/numero04.jpg', 1, 1, 0, '2023-11-22 01:26:58', '2023-11-22 01:26:58'),
(5, 'GOU006', 'Gubia para tallado de madera\r\n', 'Gubia para tallado de madera\r\n', 0, 0.100, NULL, 0, 0, 0, 4.990, 1, 0, 0, 'Gubia de acero templado para tallado de madera con mango ergonómico.\r\n', 'http://127.0.0.1:8000/assets/images/productsThumbnails/numero05.jpg', 1, 1, 0, '2023-11-22 01:26:58', '2023-11-22 01:26:58'),
(6, 'SAN007', 'Lijadora de mano para madera', 'Herramienta manual', 0, 0.400, NULL, 0, 0, 0, 9.990, 1, 0, 1, 'Lijadora de mano con mango ergonómico y hoja de lija reemplazable.\r\n', 'http://127.0.0.1:8000/assets/images/productsThumbnails/numero06.jpg', 1, 1, 0, '2023-11-22 01:30:53', '2023-11-22 01:30:53'),
(7, 'CHI008', 'Cincel para carpintería', 'Herramienta manual', 0, 0.300, NULL, 0, 0, 0, 8.990, 0, 0, 1, 'Cincel de carpintero con hoja afilada y mango ergonómico.\r\n', 'http://127.0.0.1:8000/assets/images/productsThumbnails/numero07.jpg', 1, 1, 0, '2023-11-22 01:30:53', '2023-11-22 01:30:53'),
(10, 'HAM002', 'Martillo de carpintero\r\n', 'Herramienta manual\r\n', 0, 0.500, NULL, 0, 0, 0, 10.990, 1, 0, 0, 'Martillo de carpintero de alta calidad con mango de madera.\r\n', 'http://127.0.0.1:8000/assets/images/productsThumbnails/numero08.jpg', 1, 1, 0, '2023-11-22 01:33:32', '2023-11-22 01:33:32'),
(11, 'ELE001', 'Taladro eléctrico', 'Herramienta eléctrica', 0, 2.000, NULL, 1, 1, 0, 49.990, 0, 0, 0, 'Taladro eléctrico de alta potencia con velocidad ajustable y brocas intercambiables. Ideal para perforar madera, metal y plástico.', 'http://127.0.0.1:8000/assets/images/productsThumbnails/numero09.jpg', 1, 2, 0, '2023-12-05 02:22:05', '2023-12-05 02:22:05'),
(12, 'ELE002', 'Sierra circular', 'Herramienta eléctrica', 3, 3.000, NULL, 0, 1, 0, 79.990, 1, 0, 0, 'Sierra circular potente y precisa con hoja de corte ajustable. Ideal para cortar madera, plástico y materiales similares.', 'http://127.0.0.1:8000/assets/images/productsThumbnails/numero10.jpg', 6, 2, 0, '2023-12-05 02:31:48', '2023-12-05 02:31:48'),
(13, 'ELE003', 'Amoladora angular', 'Herramienta eléctrica', 0, 2.500, NULL, 1, 1, 0, 69.990, 1, 0, 0, 'Amoladora angular potente y versátil con disco de corte ajustable. Ideal para cortar metal, piedra y otros materiales duros.', 'http://127.0.0.1:8000/assets/images/productsThumbnails/numero11.jpg', 7, 2, 0, '2023-12-05 02:31:48', '2023-12-05 02:31:48'),
(14, 'ELE004', 'Lijadora orbital', 'Herramienta eléctrica', 0, 1.500, NULL, 1, 0, 0, 39.990, 0, 0, 1, 'Lijadora orbital de alta velocidad con sistema de extracción de polvo. Ideal para lijar superficies de madera, metal y plástico.', 'http://127.0.0.1:8000/assets/images/productsThumbnails/numero12.jpg', 7, 2, 0, '2023-12-05 02:37:06', '2023-12-05 02:37:06'),
(15, 'ELE005', 'Taladro percutor', 'Herramienta eléctrica', 0, 2.200, NULL, 1, 1, 0, 59.990, 1, 0, 0, 'Taladro percutor potente con función de percusión para perforar materiales duros como concreto y ladrillo. Incluye brocas de diferentes tamaños.', 'http://127.0.0.1:8000/assets/images/productsThumbnails/numero13.jpg', 1, 2, 0, '2023-12-05 02:37:06', '2023-12-05 02:37:06'),
(16, 'ELE006', 'Atornillador eléctrico', 'Herramienta eléctrica', 0, 1.000, NULL, 1, 1, 0, 29.990, 0, 0, 0, 'Atornillador eléctrico compacto y ligero con ajuste de torque. Ideal para atornillar y desatornillar tornillos en diferentes materiales.', 'http://127.0.0.1:8000/assets/images/productsThumbnails/numero14.jpg', 1, 2, 0, '2023-12-05 02:38:48', '2023-12-05 02:38:48'),
(17, 'MC001', 'Tablero de madera contrachapada', 'Material de carpintería', 0, 0.000, 0.000, 0, 1, 0, 29.990, 0, 0, 0, 'Tablero de madera contrachapada de alta calidad, ideal para proyectos de carpintería y construcción. Resistente y duradero.', 'http://127.0.0.1:8000/assets/images/productsThumbnails/numero15.jpg', 1, 3, 0, '2023-12-07 10:58:34', '2023-12-07 10:58:34'),
(18, 'MC002', 'Listón de madera', 'Material de carpintería', 0, 0.000, 0.000, 1, 1, 0, 9.900, 1, 0, 1, 'Listón de madera de pino de alta calidad, perfecto para proyectos de carpintería y bricolaje. Versátil y fácil de trabajar.', 'http://127.0.0.1:8000/assets/images/productsThumbnails/numero16.jpg', 1, 3, 0, '2023-12-07 12:38:09', '2023-12-07 12:38:09'),
(19, 'MC003', 'Tornillos para madera', 'Material de carpintería', 0, 0.100, 1.000, 0, 100, 50, 4.990, 1, 0, 1, 'Tornillos de acero galvanizado para uso en madera. Rosca profunda y resistente para una sujeción segura en proyectos de carpintería.', 'http://127.0.0.1:8000/assets/images/productsThumbnails/numero17.jpg', 1, 3, 0, '2023-12-07 12:48:12', '2023-12-07 12:48:12'),
(25, 'MC004', 'Barniz para madera', 'Material de carpintería', 0, 0.500, 0.000, 1, 1, 50, 12.990, 1, 0, 0, 'Barniz transparente de alta calidad para proteger y embellecer la madera. Resistente al agua y a los rayos UV.', 'http://127.0.0.1:8000/assets/images/productsThumbnails/numero18.jpg', 1, 3, 0, '2023-12-07 18:53:18', '2023-12-07 18:55:47');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ff_providers`
--

CREATE TABLE `ff_providers` (
  `id` int(11) NOT NULL,
  `rif` varchar(20) NOT NULL,
  `name` varchar(64) NOT NULL,
  `address` varchar(1024) NOT NULL,
  `email` varchar(64) DEFAULT NULL,
  `phone_number` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ff_sections`
--

CREATE TABLE `ff_sections` (
  `id` int(3) NOT NULL,
  `name` varchar(64) NOT NULL,
  `imageUrl` varchar(1024) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `ff_sections`
--

INSERT INTO `ff_sections` (`id`, `name`, `imageUrl`, `createdAt`, `updatedAt`) VALUES
(1, 'Herramientas Carpintería', 'https://picsum.photos/1440/900', '2023-11-21 02:25:11', '2023-11-21 02:25:11'),
(2, 'Herramientas Eléctricas', 'https://picsum.photos/1440/900', '2023-11-21 02:25:11', '2023-11-21 02:25:11'),
(3, 'Materiales para carpintería', 'https://picsum.photos/1440/900', '2023-11-21 03:14:36', '2023-11-21 03:14:36'),
(4, 'Materiales Eléctricos', 'https://picsum.photos/1440/900', '2023-11-21 03:14:36', '2023-11-21 03:14:36'),
(5, 'Herrajes y accesorios', 'https://picsum.photos/1440/900', '2023-11-21 03:17:40', '2023-11-21 03:17:40'),
(6, 'Mobiliario y decoración', 'https://picsum.photos/1440/900', '2023-11-21 03:17:40', '2023-11-21 03:17:40'),
(7, 'Protección y seguridad', 'https://picsum.photos/1440/900', '2023-11-21 03:18:33', '2023-11-21 03:18:33'),
(8, 'Ofertas y promociones', 'https://picsum.photos/1440/900', '2023-11-21 03:18:33', '2023-11-21 03:18:33');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ff_sub_categories`
--

CREATE TABLE `ff_sub_categories` (
  `id` int(5) NOT NULL,
  `category_id` int(5) NOT NULL,
  `name` varchar(64) NOT NULL,
  `narrative` varchar(1024) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ff_testconect`
--

CREATE TABLE `ff_testconect` (
  `id` int(11) NOT NULL,
  `name` varchar(15) NOT NULL,
  `conected` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ff_users`
--

CREATE TABLE `ff_users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'campo identificador de eliminación lógica',
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `ff_users`
--

INSERT INTO `ff_users` (`id`, `name`, `email`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'Raul', 'raulpinero1985@hotmail.com', 1, '2023-11-16 17:42:53', '2023-11-16 17:42:53'),
(2, 'Javier Lopez', 'Xavi10@hotmail.com', 1, '2023-11-16 17:42:53', '2023-11-16 19:22:01'),
(4, '', 'testing_a_test@hotmail.com', 1, '2023-11-16 18:13:47', '2023-11-16 18:13:47'),
(6, '', 'testing@hotmail.com', 1, '2023-11-16 18:29:52', '2023-11-16 18:29:52'),
(7, '', 'mealisa@hotmail.com', 1, '2023-11-16 19:01:24', '2023-11-16 19:01:24'),
(8, 'Altay', 'altay@hotmail.com', 1, '2023-11-16 19:03:42', '2023-11-22 02:07:24'),
(9, 'AltMariaay', 'maria@hotmail.com', 1, '2023-11-16 22:54:44', '2023-11-16 22:54:44');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `ff_categories`
--
ALTER TABLE `ff_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indices de la tabla `ff_clients`
--
ALTER TABLE `ff_clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `rif` (`rif`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indices de la tabla `ff_client_orders`
--
ALTER TABLE `ff_client_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `ff_orders`
--
ALTER TABLE `ff_orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `client_id` (`client_id`),
  ADD UNIQUE KEY `pay_number` (`pay_number`);

--
-- Indices de la tabla `ff_order_details`
--
ALTER TABLE `ff_order_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_id` (`order_id`);

--
-- Indices de la tabla `ff_products`
--
ALTER TABLE `ff_products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indices de la tabla `ff_providers`
--
ALTER TABLE `ff_providers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `rif` (`rif`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indices de la tabla `ff_sections`
--
ALTER TABLE `ff_sections`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indices de la tabla `ff_sub_categories`
--
ALTER TABLE `ff_sub_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category_id` (`category_id`,`name`);

--
-- Indices de la tabla `ff_testconect`
--
ALTER TABLE `ff_testconect`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `ff_users`
--
ALTER TABLE `ff_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `ff_categories`
--
ALTER TABLE `ff_categories`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT COMMENT 'IDdeCategoría', AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de la tabla `ff_clients`
--
ALTER TABLE `ff_clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `ff_client_orders`
--
ALTER TABLE `ff_client_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `ff_orders`
--
ALTER TABLE `ff_orders`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT COMMENT 'order_idDevControl';

--
-- AUTO_INCREMENT de la tabla `ff_order_details`
--
ALTER TABLE `ff_order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'IDControlDev';

--
-- AUTO_INCREMENT de la tabla `ff_products`
--
ALTER TABLE `ff_products`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT COMMENT 'IDControlDev', AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de la tabla `ff_providers`
--
ALTER TABLE `ff_providers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `ff_sections`
--
ALTER TABLE `ff_sections`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `ff_sub_categories`
--
ALTER TABLE `ff_sub_categories`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `ff_testconect`
--
ALTER TABLE `ff_testconect`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `ff_users`
--
ALTER TABLE `ff_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
